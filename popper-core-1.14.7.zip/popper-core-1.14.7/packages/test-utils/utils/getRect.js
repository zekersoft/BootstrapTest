export default function getRect(element) {
  return element.getBoundingClientRect();
}
